package com.matin.aisignalpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF070B14)
private val Panel = Color(0xFF111A2B)
private val Panel2 = Color(0xFF172238)
private val Cyan = Color(0xFF36D9F5)
private val Green = Color(0xFF32E6A1)
private val Red = Color(0xFFFF657A)
private val Muted = Color(0xFF91A2BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SignalApp() }
    }
}

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)
data class Signal(val symbol: String, val price: Double, val change: Double, val volume: Double, val side: String, val score: Int, val rsi: Double, val emaFast: Double, val emaSlow: Double, val macd: Double, val reason: String, val candles: List<Candle>)

private object MarketApi {
    private fun get(path: String): String {
        val c = (URL("https://api.binance.com$path").openConnection() as HttpURLConnection)
        c.connectTimeout = 12000; c.readTimeout = 15000; c.requestMethod = "GET"
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("Binance HTTP $code: ${body.take(180)}")
            return body
        } finally { c.disconnect() }
    }

    suspend fun scan(): List<Signal> = withContext(Dispatchers.IO) {
        val info = JSONObject(get("/api/v3/exchangeInfo"))
        val allowed = mutableSetOf<String>()
        val symbols = info.getJSONArray("symbols")
        for (i in 0 until symbols.length()) {
            val s = symbols.getJSONObject(i)
            if (s.optString("status") == "TRADING" && s.optString("quoteAsset") == "USDT" && s.optString("isSpotTradingAllowed", "true") != "false") allowed.add(s.optString("symbol"))
        }
        val tickers = JSONArray(get("/api/v3/ticker/24hr"))
        val ranked = mutableListOf<JSONObject>()
        for (i in 0 until tickers.length()) {
            val t = tickers.getJSONObject(i)
            if (allowed.contains(t.optString("symbol"))) ranked.add(t)
        }
        // Scan the most liquid pairs first to respect Binance request limits; the full eligible universe is discovered above.
        ranked.sortByDescending { it.optDouble("quoteVolume") }
        ranked.take(45).mapNotNull { t ->
            try {
                val symbol = t.getString("symbol")
                val arr = JSONArray(get("/api/v3/klines?symbol=$symbol&interval=15m&limit=100"))
                val candles = (0 until arr.length()).map { i ->
                    val a = arr.getJSONArray(i)
                    Candle(a.getLong(0), a.getString(1).toDouble(), a.getString(2).toDouble(), a.getString(3).toDouble(), a.getString(4).toDouble(), a.getString(5).toDouble())
                }
                if (candles.size < 35) null else makeSignal(symbol, t.optDouble("lastPrice"), t.optDouble("priceChangePercent"), t.optDouble("quoteVolume"), candles)
            } catch (_: Exception) { null }
        }.sortedByDescending { it.score }
    }

    private fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1)
        return values.drop(1).fold(values.first()) { acc, v -> v * k + acc * (1 - k) }
    }
    private fun rsi(values: List<Double>, period: Int = 14): Double {
        val diffs = values.zipWithNext { a, b -> b - a }.takeLast(period)
        val gains = diffs.filter { it > 0 }.sum() / period
        val losses = -diffs.filter { it < 0 }.sum() / period
        if (losses == 0.0) return 100.0
        return 100.0 - 100.0 / (1.0 + gains / losses)
    }
    private fun makeSignal(symbol: String, price: Double, change: Double, volume: Double, candles: List<Candle>): Signal {
        val closes = candles.map { it.close }
        val e9 = ema(closes.takeLast(60), 9); val e21 = ema(closes.takeLast(60), 21)
        val e12 = ema(closes.takeLast(60), 12); val e26 = ema(closes.takeLast(60), 26)
        val macd = e12 - e26
        val rsi = rsi(closes)
        val recentVol = candles.takeLast(5).map { it.volume }.average()
        val priorVol = candles.dropLast(5).takeLast(20).map { it.volume }.average().coerceAtLeast(0.000001)
        val volumeRatio = recentVol / priorVol
        var bull = 0; var bear = 0
        if (e9 > e21) bull++ else bear++
        if (macd > 0) bull++ else bear++
        if (rsi in 50.0..68.0) bull++ else if (rsi < 45.0) bear++
        if (change > 0) bull++ else if (change < 0) bear++
        if (volumeRatio > 1.15) { if (bull >= bear) bull++ else bear++ }
        val side = when { bull >= 3 && bull > bear -> "LONG"; bear >= 3 && bear > bull -> "SHORT"; else -> "WAIT" }
        val score = (max(bull, bear) * 18 + min(10.0, abs(rsi - 50.0) / 5).toInt()).coerceIn(0, 96)
        val reason = "RSI ${"%.1f".format(rsi)} • EMA ${if (e9 > e21) "صعودی" else "نزولی"} • MACD ${if (macd > 0) "مثبت" else "منفی"} • حجم ${"%.2f".format(volumeRatio)}x"
        return Signal(symbol, price, change, volume, side, score, rsi, e9, e21, macd, reason, candles)
    }

    suspend fun aiExplain(apiKey: String, model: String, signal: Signal): String = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "ابتدا کلید OpenRouter را در تنظیمات وارد کن" }
        val prompt = "Review this educational market-data signal. Do not invent data or promise profit. Explain uncertainty briefly. Symbol=${signal.symbol}, price=${signal.price}, label=${signal.side}, score=${signal.score}, RSI=${signal.rsi}, EMA9=${signal.emaFast}, EMA21=${signal.emaSlow}, MACD=${signal.macd}, 24h change=${signal.change}%. This is analysis, not an instruction to trade."
        val payload = JSONObject().put("model", model.ifBlank { "openai/gpt-4o-mini" }).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt))).put("temperature", 0.2)
        val conn = (URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 25000; conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $apiKey"); conn.setRequestProperty("Content-Type", "application/json")
        try {
            conn.outputStream.use { it.write(payload.toString().toByteArray()) }
            val code = conn.responseCode; val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("OpenRouter HTTP $code: ${body.take(250)}")
            JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "پاسخی دریافت نشد")
        } finally { conn.disconnect() }
    }
}

@Composable
fun SignalApp() {
    val scope = rememberCoroutineScope()
    var signals by remember { mutableStateOf<List<Signal>>(emptyList()) }
    var selected by remember { mutableStateOf<Signal?>(null) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("برای دریافت داده زنده، اسکن بازار را بزن") }
    var tab by remember { mutableStateOf("SIGNALS") }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("openai/gpt-4o-mini") }
    var aiText by remember { mutableStateOf("") }
    var aiLoading by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AI SIGNAL", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("PRO  /  LIVE MARKET INTELLIGENCE", color = Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                Box(Modifier.background(Color(0xFF12352F), RoundedCornerShape(30.dp)).padding(horizontal = 12.dp, vertical = 7.dp)) { Text("● LIVE DATA", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SIGNALS", "CHART", "AI SETUP").forEach { label ->
                    Box(Modifier.weight(1f).background(if (tab == label) Color(0xFF123044) else Panel, RoundedCornerShape(12.dp)).clickable { tab = label }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Text(label, color = if (tab == label) Cyan else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            when (tab) {
                "SIGNALS" -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricCard("PAIRS", if (signals.isEmpty()) "—" else signals.size.toString(), Modifier.weight(1f))
                        MetricCard("LONG", signals.count { it.side == "LONG" }.toString(), Modifier.weight(1f), Green)
                        MetricCard("SHORT", signals.count { it.side == "SHORT" }.toString(), Modifier.weight(1f), Red)
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        scope.launch { loading = true; status = "در حال دریافت بازار و تحلیل کندل‌ها…"; try { signals = MarketApi.scan(); selected = signals.firstOrNull(); status = "به‌روزرسانی شد • ${signals.size} جفت‌ارز با نقدشوندگی بالا تحلیل شدند" } catch (e: Exception) { status = "خطا: ${e.message ?: "اتصال برقرار نشد"}" } finally { loading = false } }
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087E91)), shape = RoundedCornerShape(14.dp)) {
                        Text(if (loading) "SCANNING MARKET…" else "⟳  SCAN LIVE MARKET", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 5.dp))
                    }
                    Text(status, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                        items(signals) { s -> SignalCard(s, selected?.symbol == s.symbol) { selected = s; tab = "CHART"; aiText = "" } }
                    }
                }
                "CHART" -> {
                    val s = selected
                    if (s == null) Text("ابتدا بازار را اسکن کن و یک نماد را انتخاب کن", color = Muted)
                    else {
                        Text(s.symbol, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("$" + fmt(s.price) + "   " + (if (s.change >= 0) "+" else "") + "${"%.2f".format(s.change)}%  •  15m", color = if (s.change >= 0) Green else Red, fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        PriceChart(s.candles, Modifier.fillMaxWidth().height(220.dp))
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricCard("RSI 14", "${"%.1f".format(s.rsi)}", Modifier.weight(1f))
                            MetricCard("EMA 9", fmt(s.emaFast), Modifier.weight(1f), Cyan)
                            MetricCard("EMA 21", fmt(s.emaSlow), Modifier.weight(1f), Muted)
                        }
                        Spacer(Modifier.height(12.dp))
                        SignalCard(s, true) {}
                        Text("${s.reason}\nحجم ۲۴ ساعته: $${compact(s.volume)}", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                    }
                }
                else -> {
                    Text("OPENROUTER AI", color = Cyan, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("کلید فقط روی همین دستگاه ذخیره می‌شود. آن را در مخزن GitHub قرار نده.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 10.dp))
                    InputField("OpenRouter API Key", apiKey, { apiKey = it }, true)
                    Spacer(Modifier.height(10.dp))
                    InputField("Model ID", model, { model = it })
                    Text("پیش‌فرض: openai/gpt-4o-mini  •  می‌توانی شناسه مدل دیگری از OpenRouter وارد کنی.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 8.dp))
                    Button(onClick = { val s = selected; if (s == null) aiText = "اول بازار را اسکن و یک نماد را انتخاب کن." else scope.launch { aiLoading = true; aiText = "در حال تحلیل با OpenRouter…"; try { aiText = MarketApi.aiExplain(apiKey, model, s) } catch (e: Exception) { aiText = "خطا: ${e.message}" } finally { aiLoading = false } } }, enabled = !aiLoading, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6043A8))) { Text(if (aiLoading) "ANALYZING…" else "✦  ANALYZE SELECTED SIGNAL") }
                    if (aiText.isNotBlank()) Text(aiText, color = Color.White, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(top = 14.dp).background(Panel, RoundedCornerShape(14.dp)).padding(14.dp))
                }
            }
        }
    }
}

@Composable private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier, color: Color = Color.White) {
    Column(modifier.background(Panel, RoundedCornerShape(13.dp)).padding(11.dp)) { Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
}

@Composable private fun SignalCard(s: Signal, selected: Boolean, onClick: () -> Unit) {
    val color = when (s.side) { "LONG" -> Green; "SHORT" -> Red; else -> Color(0xFFFFC66D) }
    Row(Modifier.fillMaxWidth().background(if (selected) Color(0xFF17283B) else Panel, RoundedCornerShape(15.dp)).clickable { onClick() }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(s.symbol, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("$${fmt(s.price)}  •  RSI ${"%.0f".format(s.rsi)}", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            Text(s.reason, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(s.side, color = color, fontSize = 12.sp, fontWeight = FontWeight.Black)
            Text("${s.score}/100", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
            Text("${if (s.change >= 0) "+" else ""}${"%.2f".format(s.change)}%", color = if (s.change >= 0) Green else Red, fontSize = 10.sp)
        }
    }
}

@Composable private fun PriceChart(candles: List<Candle>, modifier: Modifier = Modifier) {
    Canvas(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
        if (candles.isEmpty()) return@Canvas
        val data = candles.takeLast(60); val lo = data.minOf { it.low }; val hi = data.maxOf { it.high }; val range = (hi - lo).coerceAtLeast(0.0000001)
        val step = size.width / data.size; val bodyW = step * 0.58f
        repeat(4) { i -> val y = size.height * i / 3f; drawLine(Color(0xFF26354A), Offset(0f, y), Offset(size.width, y), 1f) }
        data.forEachIndexed { i, c ->
            val x = step * i + step / 2f
            fun y(v: Double) = size.height - ((v - lo) / range * size.height).toFloat()
            val up = c.close >= c.open; val color = if (up) Green else Red
            drawLine(color, Offset(x, y(c.high)), Offset(x, y(c.low)), 1.5f, cap = StrokeCap.Round)
            val top = min(y(c.open), y(c.close)); val bottom = max(y(c.open), y(c.close)).coerceAtLeast(top + 2f)
            drawRect(color, Offset(x - bodyW / 2, top), androidx.compose.ui.geometry.Size(bodyW, bottom - top))
        }
    }
}

@Composable private fun InputField(label: String, value: String, onValue: (String) -> Unit, secret: Boolean = false) {
    Column {
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp))
        BasicTextField(value, onValue, modifier = Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(12.dp)).padding(14.dp), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp), decorationBox = { inner -> if (value.isEmpty()) Text(if (secret) "sk-or-v1-…" else label, color = Muted, fontSize = 12.sp); inner() })
    }
}

private fun fmt(v: Double): String = if (v >= 1000) "%.2f".format(v) else if (v >= 1) "%.4f".format(v) else "%.7f".format(v)
private fun compact(v: Double): String = when { v >= 1e9 -> "%.2fB".format(v / 1e9); v >= 1e6 -> "%.2fM".format(v / 1e6); v >= 1e3 -> "%.2fK".format(v / 1e3); else -> "%.0f".format(v) }
