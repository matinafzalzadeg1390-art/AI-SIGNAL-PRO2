# AI SIGNAL PRO

Android app (Kotlin + Jetpack Compose) for educational market analysis using live Binance Spot market data.

## Features
- Discovers active Binance Spot USDT symbols and reads their 24-hour ticker data.
- Fetches 15-minute candles for the 45 highest-quote-volume eligible pairs per scan to keep public API usage practical.
- Calculates RSI(14), EMA(9/21), MACD direction and recent-vs-baseline volume; produces rule-based LONG/SHORT/WAIT analytical labels.
- Candlestick chart for the selected symbol.
- Optional OpenRouter explanation. Enter your personal API key in the app's AI Setup tab; never commit it to GitHub.

## GitHub build
1. Create `.github/workflows/build.yml` in the repository and paste the workflow from this project.
2. Upload `AI-SIGNAL-PRO2-Source.zip` to the repository root (do not extract it).
3. Open Actions and run **Build AI SIGNAL PRO APK** if it did not start automatically.
4. Open the successful run, download `AI-SIGNAL-PRO-APK`, extract it, and install `app-debug.apk`.

## Notes
- The scanner discovers the eligible symbol universe, but downloads candles for the 45 highest-volume pairs per scan to limit API requests. Binance rate limits and regional/network availability apply.
- LONG/SHORT/WAIT are analytical labels, not guaranteed forecasts or instructions to place trades. The app does not execute orders.
- OpenRouter is optional. AI explanations require your own key and may incur provider charges. The key is entered on-device and is not included in the repository. Local app storage is not a secure secret vault.
- Uses public Binance endpoints; no Binance account or trading permissions are requested.
